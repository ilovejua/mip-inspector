import argparse
import json
from typing import Any, Dict, List, Optional

import yaml
from pymilvus import (
    connections,
    utility,
    Collection,
    FieldSchema,
    CollectionSchema,
    DataType,
    Function,
    FunctionType,
)

# -------------------------
# dtype mapping
# -------------------------
_DT_MAP = {
    "BOOL": DataType.BOOL,
    "INT8": DataType.INT8,
    "INT16": DataType.INT16,
    "INT32": DataType.INT32,
    "INT64": DataType.INT64,
    "FLOAT": DataType.FLOAT,
    "DOUBLE": DataType.DOUBLE,
    "VARCHAR": DataType.VARCHAR,
    "JSON": DataType.JSON,
    "FLOAT_VECTOR": DataType.FLOAT_VECTOR,
    "BINARY_VECTOR": DataType.BINARY_VECTOR,
    "SPARSE_FLOAT_VECTOR": DataType.SPARSE_FLOAT_VECTOR,
    "ARRAY": DataType.ARRAY,
}

_FN_MAP = {
    "BM25": FunctionType.BM25,
}


def _norm_key(s: str) -> str:
    return str(s).strip().upper().replace(" ", "").replace("-", "_")


def _dtype_from_str(s: str) -> DataType:
    k = _norm_key(s)
    # allow aliases
    if k in ("VARCHAR", "VARCHAR_TYPE", "VAR_CHAR", "VARCHR", "VARCHAR_"):
        k = "VARCHAR"
    if k in ("FLOATVECTOR", "FLOAT_VECTOR"):
        k = "FLOAT_VECTOR"
    if k in ("SPARSEFLOATVECTOR", "SPARSE_FLOAT_VECTOR"):
        k = "SPARSE_FLOAT_VECTOR"
    if k not in _DT_MAP:
        raise ValueError(f"Unsupported dtype '{s}'. Supported: {sorted(_DT_MAP.keys())}")
    return _DT_MAP[k]


def _maybe_json_string(x: Any) -> str:
    """Serialize dict/list to JSON string; pass through string."""
    if isinstance(x, str):
        # validate if it's json; if not, still pass through
        try:
            json.loads(x)
        except Exception:
            return x
        return x
    return json.dumps(x, ensure_ascii=False, separators=(",", ":"))


def _build_field(fc: Dict[str, Any]) -> FieldSchema:
    """
    Build FieldSchema robustly across pymilvus versions:
    - Try direct args (max_length/dim/element_type/max_capacity/enable_analyzer/analyzer_params)
    - Fallback to type_params dict if needed
    """
    name = fc["name"]
    dtype = _dtype_from_str(fc["dtype"])

    base_kwargs: Dict[str, Any] = dict(
        name=name,
        dtype=dtype,
        description=fc.get("description", ""),
        nullable=bool(fc.get("nullable", True)),
        is_primary=bool(fc.get("is_primary", False)),
        auto_id=bool(fc.get("auto_id", False)),
    )

    # Per-type extras (preferred direct kwargs)
    direct_kwargs: Dict[str, Any] = {}
    type_params: Dict[str, Any] = {}

    if dtype == DataType.VARCHAR:
        if "max_length" not in fc:
            raise ValueError(f"VARCHAR field '{name}' requires max_length")
        max_length = int(fc["max_length"])
        direct_kwargs["max_length"] = max_length
        type_params["max_length"] = str(max_length)

        if bool(fc.get("enable_analyzer", False)):
            direct_kwargs["enable_analyzer"] = True
            type_params["enable_analyzer"] = "true"

            analyzer_params = fc.get("analyzer_params")
            if analyzer_params is not None:
                # params가 있을 때만 적용
                direct_kwargs["analyzer_params"] = analyzer_params
                type_params["analyzer_params"] = _maybe_json_string(analyzer_params)

    elif dtype in (DataType.FLOAT_VECTOR, DataType.BINARY_VECTOR):
        if "dim" not in fc:
            raise ValueError(f"Vector field '{name}' requires dim")
        dim = int(fc["dim"])
        direct_kwargs["dim"] = dim
        type_params["dim"] = str(dim)

    elif dtype == DataType.ARRAY:
        if "element_type" not in fc:
            raise ValueError(f"ARRAY field '{name}' requires element_type")
        if "max_capacity" not in fc:
            raise ValueError(f"ARRAY field '{name}' requires max_capacity")

        element_type = _dtype_from_str(fc["element_type"])
        max_capacity = int(fc["max_capacity"])

        direct_kwargs["element_type"] = element_type
        direct_kwargs["max_capacity"] = max_capacity
        type_params["max_capacity"] = str(max_capacity)

        # ARRAY<VARCHAR>는 원소 max_length가 필요
        if element_type == DataType.VARCHAR:
            if "max_length" not in fc:
                raise ValueError(f"ARRAY<VARCHAR> field '{name}' requires max_length")
            max_length = int(fc["max_length"])
            direct_kwargs["max_length"] = max_length
            type_params["max_length"] = str(max_length)

    # SPARSE_FLOAT_VECTOR / JSON / BOOL / INT* 등은 추가 파라미터 없음

    # ---- Try 1) direct kwargs
    try:
        return FieldSchema(**base_kwargs, **direct_kwargs)
    except TypeError:
        pass

    # ---- Try 2) fallback with type_params
    try:
        # 일부 버전은 type_params를 받음
        return FieldSchema(**base_kwargs, type_params=type_params)
    except TypeError as e:
        raise TypeError(
            f"Failed to build FieldSchema for '{name}'. "
            f"Your pymilvus version may not support analyzer/array/type_params in this form. "
            f"Original error: {e}"
        )


def _build_functions(cfg: Dict[str, Any]) -> List[Function]:
    fns: List[Function] = []

    # Preferred: explicit functions list
    for fn_cfg in (cfg.get("functions") or []):
        fn_type = _norm_key(fn_cfg["type"])
        if fn_type not in _FN_MAP:
            raise ValueError(f"Unsupported function type '{fn_cfg['type']}'. Supported: {sorted(_FN_MAP.keys())}")

        fns.append(
            Function(
                name=fn_cfg["name"],
                function_type=_FN_MAP[fn_type],
                input_field_names=list(fn_cfg["input_fields"]),
                output_field_names=list(fn_cfg["output_fields"]),
            )
        )

    # Optional: bm25 mapping shorthand {out_field: in_field}
    bm25_map: Dict[str, str] = cfg.get("bm25") or {}
    for out_field, in_field in bm25_map.items():
        fns.append(
            Function(
                name=f"{in_field}_bm25_emb",
                function_type=FunctionType.BM25,
                input_field_names=[in_field],
                output_field_names=[out_field],
            )
        )

    # Dedup by (name)
    uniq: Dict[str, Function] = {}
    for fn in fns:
        uniq[fn.name] = fn
    return list(uniq.values())


def _create_indexes(col: Collection, indexes_cfg: Optional[List[Dict[str, Any]]]) -> None:
    if not indexes_cfg:
        return
    for idx in indexes_cfg:
        col.create_index(field_name=idx["field"], index_params=idx["params"])


def main() -> None:
    ap = argparse.ArgumentParser(description="Create a Milvus collection from YAML schema (kist_approval compatible).")
    ap.add_argument("--config", required=True, help="Path to YAML config")
    ap.add_argument("--drop-if-exists", action="store_true", help="Drop collection if exists")
    args = ap.parse_args()

    with open(args.config, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)

    connections.connect(alias="default", host=cfg["host"], port=cfg["port"])

    name = cfg["collection_name"]
    if utility.has_collection(name):
        if args.drop_if_exists or bool(cfg.get("drop_if_exists", False)):
            Collection(name).drop()
        else:
            raise RuntimeError(f"Collection exists: {name} (use --drop-if-exists or drop_if_exists: true)")

    # fields
    fields_cfg = cfg.get("fields") or []
    if not fields_cfg:
        raise ValueError("config must include non-empty 'fields'")

    fields = [_build_field(fc) for fc in fields_cfg]

    # pk validation (exactly 1)
    pk_fields = [f for f in fields if getattr(f, "is_primary", False)]
    if len(pk_fields) != 1:
        raise ValueError(f"Primary key must be exactly 1 field, got {len(pk_fields)}: {[f.name for f in pk_fields]}")

    # functions (BM25)
    functions = _build_functions(cfg)

    # schema
    schema_kwargs: Dict[str, Any] = dict(
        fields=fields,
        functions=functions or None,
        description=cfg.get("description", ""),
        enable_dynamic_field=bool(cfg.get("enable_dynamic_field", False)),
    )
    # some versions accept auto_id at schema level
    if "auto_id" in cfg:
        schema_kwargs["auto_id"] = bool(cfg.get("auto_id", False))

    schema = CollectionSchema(**schema_kwargs)

    col = Collection(name=name, schema=schema)

    # indexes (optional; JSON에서 못 뽑는 경우가 많아서 YAML에 명시했을 때만)
    _create_indexes(col, cfg.get("indexes"))

    if bool(cfg.get("load", False)):
        col.load()

    print("created:", col.name)
    print("fields:", [f.name for f in col.schema.fields])
    if functions:
        print("functions:", [fn.name for fn in functions])
    if cfg.get("indexes"):
        print("indexes:", [(i.field_name, i.params) for i in col.indexes])


if __name__ == "__main__":
    main()
